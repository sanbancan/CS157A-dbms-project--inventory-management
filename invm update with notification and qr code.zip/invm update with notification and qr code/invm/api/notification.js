const nodemailer = require('nodemailer');

// Configure the transporter
const transporter = nodemailer.createTransport({
    service: 'gmail', // Use your email provider
    auth: {
        user: 'your-email@gmail.com', // Replace with your email
        pass: 'your-email-password', // Replace with your email password or app password
    },
});

// Function to send an email
const sendNotification = async (recipient, subject, message) => {
    const mailOptions = {
        from: 'your-email@gmail.com', // Sender email
        to: recipient, // Recipient email
        subject: subject, // Email subject
        text: message, // Email body
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log('Notification sent successfully!');
    } catch (error) {
        console.error('Error sending notification:', error);
    }
};

module.exports = { sendNotification };
